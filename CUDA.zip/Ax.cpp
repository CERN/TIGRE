
/**
 * @file trilinear.cpp
 * @brief MEX gateway for trilinear texture memory interpolation.
 * author: Ander Biguri ander.biguri@gmail.com
 *
 */

#include "tmwtypes.h"
#include "mex.h"
#include "matrix.h"
#include "projection.hpp"
#include <string.h>
/**
 * MEX gateway
 */



void mexFunction(int  nlhs , mxArray *plhs[],
                 int nrhs, mxArray const *prhs[])
{
    char const * const errId = "CBCT:CUDA:Ax:InvalidInput";
    char const * const errMsgInputs = "Invalid number of inputs to MEX file.";
    char const * const errMsgImg = "Invalid dimension size of image (x) to MEX file.";
    


    //Check amount of inputs
    if (nrhs!=3) {
        mexErrMsgIdAndTxt(errId, errMsgInputs);
    }
    
    ////////////////////////// First input.
    // First input should be x from (Ax=b), or the image.
    mxArray const * const image = prhs[0];
    mwSize const numDims = mxGetNumberOfDimensions(image);
    
    // Image should be dim 3
    if (numDims!=3){
        mexErrMsgIdAndTxt(errId, errMsgImg);
    }
    // Now that input is ok, parse it to C data types.
    float const * const img = static_cast<float const *>(mxGetData(image));
    
    ///////////////////// Second input argument, 
    // Geometry structure that has all the needed geometric data.
    
    // IMPORTANT-> MAke sure Matlab creates the struct in this order.
    const char *fieldnames[10];
    fieldnames[0] = "nVoxel";
    fieldnames[1] = "sVoxel";
    fieldnames[2] = "dVoxel";
    fieldnames[3] = "nDetector";
    fieldnames[4] = "sDetector";
    fieldnames[5] = "dDetector";
    fieldnames[6] = "DSD";
    fieldnames[7] = "DSO";
    fieldnames[8] = "offOrigin";
    fieldnames[9] = "offDetector";



    if(!mxIsStruct(prhs[1]))
        mexErrMsgIdAndTxt( "CBCT:CUDA:Ax:inputNotStruct",
                "Second input must be a structure.");
    
    int nfields = mxGetNumberOfFields(prhs[1]);
    if (nfields != 10)
        mexErrMsgIdAndTxt("CBCT:CUDA:Ax:input","there are missing or extra fields in the geometry");
    
    // Check that all names are good
    mxArray    *tmp;
    size_t mrows,ncols;
    for(int ifield=0; ifield<nfields; ifield++) { 
        tmp=mxGetField(prhs[1],0,fieldnames[ifield]);
        if(tmp==NULL){
            mexPrintf("%s number: %d %s \n", "FIELD",ifield+1, fieldnames[ifield]);
                      mexErrMsgIdAndTxt( "CBCT:CUDA:Ax:inputname",
                        "Above field is missing. Check spelling. ");
        }
        switch(ifield){
            
            // cases where we want 3 input arrays.
            case 0:
            case 1:
            case 2:
            case 8:
                mrows = mxGetM(tmp);
                ncols = mxGetN(tmp); 
                if (mrows!=3 || ncols!=1){
                      mexPrintf("%s %s \n", "FIELD: ", fieldnames[ifield]);
                      mexErrMsgIdAndTxt( "CBCT:CUDA:Ax:inputsize",
                        "Above field has wrong size! Should be 3x1!");
                }
                
                break;
            // this ones should be 2x1
            case 3:
            case 4:
            case 5:
            case 9:
                mrows = mxGetM(tmp);
                ncols = mxGetN(tmp); 
                if (mrows!=2 || ncols!=1){
                      mexPrintf("%s %s \n", "FIELD: ", fieldnames[ifield]);
                      mexErrMsgIdAndTxt( "CBCT:CUDA:Ax:inputsize",
                        "Above field has wrong size! Should be 2x1!");
                }
                break;
           // this ones should be 1x1
            case 6:
            case 7:
                mrows = mxGetM(tmp);
                ncols = mxGetN(tmp); 
                if (mrows!=1 || ncols!=1){
                      mexPrintf("%s %s \n", "FIELD: ", fieldnames[ifield]);
                      mexErrMsgIdAndTxt( "CBCT:CUDA:Ax:inputsize",
                        "Above field has wrong size! Should be 1x1!");
                }
                break;
            default:
                mexErrMsgIdAndTxt( "CBCT:CUDA:Ax:input",
                        "something wrong happened. Ensure Geometric struct has correct amount of inputs.");
        }
       
     }
     // Now we know that all the input struct is good! Parse it from mxArrays to 
     // C structures that CUDA can understand.
    
    double * nVoxel, *nDetec; //we need to cast these to int
    double * sVoxel, *dVoxel,*sDetec,*dDetec, *DSO, *DSD,*offOrig,*offDetec;
    
    Geometry geo;
    geo.unitX=1;geo.unitY=1;geo.unitZ=1;
     for(int ifield=0; ifield<nfields; ifield++) { 
         tmp=mxGetField(prhs[1],0,fieldnames[ifield]);
         switch(ifield){
             case 0:
                 nVoxel=(double *)mxGetData(tmp);
                // copy data to CUDA memory
                 geo.nVoxelX=(int)nVoxel[0];
                 geo.nVoxelY=(int)nVoxel[1];
                 geo.nVoxelZ=(int)nVoxel[2];
                 break;
             case 1:
                 sVoxel=(double *)mxGetData(tmp);
                 geo.sVoxelX=sVoxel[0];
                 geo.sVoxelY=sVoxel[1];
                 geo.sVoxelZ=sVoxel[2];
                 break;
             case 2:
                 dVoxel=(double *)mxGetData(tmp);
                 geo.dVoxelX=dVoxel[0];
                 geo.dVoxelY=dVoxel[1];
                 geo.dVoxelZ=dVoxel[2];
                 break;
             case 3:
                 nDetec=(double *)mxGetData(tmp);
                 geo.nDetecU=(int)nDetec[0];
                 geo.nDetecV=(int)nDetec[1];
                 break;
             case 4:
                 sDetec=(double *)mxGetData(tmp);
                 geo.sDetecU=sDetec[0];
                 geo.sDetecV=sDetec[1];
                 break;
             case 5:
                 dDetec=(double *)mxGetData(tmp);
                 geo.dDetecU=dDetec[0];
                 geo.dDetecV=dDetec[1];
                 break;
             case 6:
                 DSD=(double *)mxGetData(tmp);
                 geo.DSD=DSD[0];
                 break;
             case 7:
                 DSO=(double *)mxGetData(tmp);
                 geo.DSO=DSO[0];
             case 8:
                 offOrig=(double *)mxGetData(tmp);
                 geo.offOrigX=offOrig[0];
                 geo.offOrigY=offOrig[1];
                 geo.offOrigZ=offOrig[2];
                 break;
             case 9:
                  offDetec=(double *)mxGetData(tmp);
                 geo.offDetecU=offDetec[0];
                 geo.offDetecV=offDetec[1];

                 break;
             default:
                 mexErrMsgIdAndTxt( "CBCT:CUDA:Ax:unknown","This shoudl not happen. Weird");
                 break;
                 
         }
     }
    
    // 3rd argument: angle of projection.
   
    mrows = mxGetM(prhs[2]);
    ncols = mxGetN(prhs[2]);
    if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) ||
        !(mrows==1) ) {
      mexErrMsgIdAndTxt( "CBCT:CUDA:Ax:input",
        "Input alpha must be a noncomplex array.");
    }
    mxArray const * const ptralphas=prhs[2];
    
    double const * const alphas = static_cast<double const *>(mxGetData(ptralphas));

    
    
    
    

    size_t num_bytes = geo.nDetecU*geo.nDetecV * sizeof(double);
    
    double** result = (double**)malloc(ncols * sizeof(double*));
    for (int i=0; i<ncols ;i++)
        result[i]=(double*)malloc(geo.nDetecU*geo.nDetecV *sizeof(double));

    // call the real function
    
    projection(img,geo,result,alphas,ncols);
    
    
    plhs[0] = mxCreateNumericMatrix(geo.nDetecU*geo.nDetecV, ncols, mxDOUBLE_CLASS, mxREAL);
    double *outProjections = mxGetPr(plhs[0]);
    
    for (int i=0; i<ncols ;i++)
        memcpy(&outProjections[geo.nDetecU*geo.nDetecV*i], result[i], geo.nDetecU*geo.nDetecV*sizeof(double));
    for (int i=0; i<ncols ;i++)
        free (result[i]);
    free(result);
    return;
    

    
}
